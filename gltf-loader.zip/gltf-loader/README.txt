LIGHTS, CAMERA, ACTION!
Displaying a 3D model in HTML with THREE.JS is a bit like making a movie. You will need:
Scene
Light
Camera
Model
Renderer
Loader
Controls

3D MODELLING
Download Blender: https://www.blender.org/
Make a model.
Scale and proportion are important.
The model is approximately 18 inches high, as per the client brief.

EXPORT THE MODEL
Export the model as .glb
https://threejs.org/docs/index.html#manual/en/introduction/Loading-3D-models
"Where possible, we recommend using glTF (GL Transmission Format). Both .GLB and .GLTF versions of the format are well supported."

THREE.JS FILES
The three.js files are frequently updated, so it is good practice to use the latest versions.
Looking through the github js examples also gives an awareness of the potential of three.js
Download the latest versions of these files from: 
https://github.com/mrdoob/three.js/

three.js		https://github.com/mrdoob/three.js/tree/dev/build
GLTFLoader.js		https://github.com/mrdoob/three.js/tree/dev/examples/js/loaders
OrbitControls.js	https://github.com/mrdoob/three.js/tree/dev/examples/js/controls

CALLING THE THREE.JS FILES IN HTML
The three.js files are called immediately after <body> is opened:

<body>
	<script src="three.js"></script>
	<script src="GLTFLoader.js"></script>
	<script src="OrbitControls.js"></script>

HOW TO RUN THINGS LOCALLY
https://threejs.org/docs/index.html#manual/en/introduction/How-to-run-things-locally
"If you load models or textures from external files, due to browsers' same origin policy security restrictions, loading from a file system will fail with a security exception." The solution: Follow the instructions to "Run a local server" on the above webpage.

Or install XAMPP from: https://www.apachefriends.org/
Place your three.js project folder in the htdocs folder:
C:\xampp\htdocs
Open this file to open the XAMPP Control Panel:
C:\xampp\xampp-control.exe
Start Apache
In your browser's address bar type: localhost/   followed by the name your project folder
E.g. if you have downloaded this tutorial folder from github and have placed it in the htdocs folder,
the URL to type in the browser's address bar would be:
localhost/gltf-loader/

LOADING YOUR OWN MODEL
At Line 50 of index.html replace 'stonehenge.glb' with the file name of your .glb model

CAMERA POSITION
As the stonehenge.glb model is only 46cm high, I adjusted the camera position as follows:

/* Camera */
camera = new THREE.PerspectiveCamera( 45, window.innerWidth / window.innerHeight, 1, 500 );
camera.position.x = 1;
camera.position.y = 1.5;
camera.position.z = 2;
scene.add( camera );

If your model is larger, you may find that the camera is inside your model, so that you can't see it.
Try pasting in the camera settings from the original KMZLoader example:
https://threejs.org/examples/#webgl_loader_kmz
and see how it changes the camera position.
Click the "<> inside the white circle" icon in the bottom right corner of the screen to view the source code.

SKETCHUP MODELS
At the time of writing, SketchUp does not export as .glb/.gltf
SketchUp does export as COLLADA .dae which you can import into Blender, then export as .glb

SOURCE CODE EDITORS
https://notepad-plus-plus.org/	(WINDOWS only)
http://brackets.io/		(MAC and WINDOWS)
